import java.lang.*;

class Ass2Q4
{
public static void main(String args[])
{
int x = 10;

System.out.println("x>>3 = " + (x >> 3));
System.out.println("x<<2 = " + (x << 2));
}
}